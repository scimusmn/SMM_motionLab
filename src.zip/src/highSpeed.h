#ifndef HIGH_SPEED
#define HIGH_SPEED

#include "ofMain.h"
#include "ofExtended.h"
#include "XStrmAPI.h"
#include "threadedImageSave\threadImageSave.h"

#define MAKELONGLONG(a,b)	((LONGLONG)(((ULONG)(a)) | ((LONGLONG)((ULONG)(b))) << 32))
#define LOLONG(a)			((LONG)a)
#define HILONG(a)			((LONG)(((LONGLONG)a)>>32))

class highSpeed {
protected:
	XS_ERROR err;
	XS_ENUMITEM xsArray[10];
	unsigned long i,nItems;

	XS_HANDLE hCam;
	XS_SETTINGS xsCfg;
	XS_FRAME frame;
	unsigned long nExp,nMinExp,maxWidth,maxHeight,nHi;
	unsigned long nPixDepth,nPeriod,nFPS;
	unsigned long nPreFrames,curPlayFrame,nStartIndex;
	unsigned long startAddLo,startAddHi,memOffset,nFrameSize;
	unsigned long lastFrame;

	unsigned long trigIndex;
	bool bNewFrame,bOpen,bRecording,bDriverLoaded,bInit;
	bool bPlaying,bFramesCaptured,bFramesSaved,bFramesReviewed,bFetching;
	unsigned char * pix;

public:
	unsigned long nFrames,nImgSize;
	unsigned long x,y;
	unsigned long width, height;
	highSpeed();
	~highSpeed();
	void intitialize(int cameraNum=0);
	void setExposure(double timeInMillis);
	unsigned long getExposure();
	void setFPS(unsigned long fps);
	unsigned long getFPS();
	void refreshSettings(string component="");
	void setROI(int x, int y, int w, int h);
	void setRotation(XS_ROT_ANGLE angle);
	void getStartAddress();
	void grabFrame();
	void processFrame(unsigned char * pixels=0);
	unsigned long imageSize();
	bool frameIsNew();
	long getMaxWidth();
	long getMaxHeight();
	void updateFrameSize();
	unsigned char * pixels();
	unsigned char * uPixels();
	void setRecordingVar(bool boolForVarNotMode);
	void beginRecord(double secondsToRecord, double portionBeforeTrigger=.5);
	void stopRecord();
	bool isRecording();
	bool isOpen();
	bool isPlaying();
	bool framesCaptured(){ return bFramesCaptured; }
	bool framesReviewed(){ return bFramesReviewed; }
	void setCaptured(bool capd){ bFramesCaptured=capd; }
	void resetFlags();
	void toggleRecord(double secondsToRecord, double portionBeforeTrigger=.5);
	void play();
	void pause();
	void resetPlayback();
	void trigger();
	void fetchFrames();
	void onExit();
	void handleError();
	void nextFrame();
	void prevFrame();
	int frameIndex(){ return curPlayFrame; }

	void fetch(){ bFetching=true; }
	bool isFetching(){ return bFetching; }
	bool retrieved(){ return bFramesSaved;}

	void draw(int x, int y);
	void update();

	ofTexture	hsText;
	ofThreadImageSave	save;
};

#endif //HIGH_SPEED